import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from fpdf import FPDF
from datetime import datetime

DB_NAME = "hfm_energy.db"
ROOM_NAME = "Demo Room"

conn = sqlite3.connect(DB_NAME)
df = pd.read_sql_query("SELECT * FROM logs", conn)
conn.close()
df["timestamp"] = pd.to_datetime(df["timestamp"])

total_alerts = int(df["alert_sent"].sum())
occupied_pct = (df["room_status"] == "OCCUPIED").mean() * 100
waste_records = df[(df["room_status"] == "EMPTY") & ((df["ac1_status"] == "ON") | (df["ac2_status"] == "ON"))]
waste_hours = len(waste_records) * (10 / 60)

UNIT_RATE = 55
AC_KW = 1.2
estimated_cost = waste_hours * AC_KW * UNIT_RATE

date_from = df["timestamp"].min().strftime("%d-%b-%Y")
date_to = df["timestamp"].max().strftime("%d-%b-%Y")

df["date"] = df["timestamp"].dt.date
daily_waste = waste_records.groupby(waste_records["timestamp"].dt.date).size()

plt.figure(figsize=(7, 3))
daily_waste.plot(kind="bar", color="#d9534f")
plt.title("Energy Waste Incidents Per Day")
plt.ylabel("Incidents")
plt.tight_layout()
plt.savefig("waste_chart.png", dpi=150)
plt.close()

pdf = FPDF()
pdf.add_page()

pdf.set_font("Helvetica", "B", 18)
pdf.cell(0, 12, "HFM Energy Saving Detection Report", ln=True, align="C")

pdf.set_font("Helvetica", "", 11)
pdf.cell(0, 8, f"Room: {ROOM_NAME}", ln=True, align="C")
pdf.cell(0, 8, f"Period: {date_from} to {date_to}", ln=True, align="C")
pdf.cell(0, 8, f"Generated on: {datetime.now().strftime('%d-%b-%Y %H:%M')}", ln=True, align="C")
pdf.ln(8)

pdf.set_font("Helvetica", "B", 13)
pdf.cell(0, 10, "Summary", ln=True)
pdf.set_font("Helvetica", "", 11)

rows = [
    ("Total Energy-Waste Alerts", str(total_alerts)),
    ("Room Occupancy %", f"{occupied_pct:.1f}%"),
    ("Estimated Wasted Hours", f"{waste_hours:.1f} hrs"),
    ("Estimated Cost Wasted", f"Rs. {estimated_cost:,.0f}"),
]

for label, value in rows:
    pdf.cell(100, 9, label, border=1)
    pdf.cell(80, 9, value, border=1, ln=True)

pdf.ln(8)
pdf.set_font("Helvetica", "B", 13)
pdf.cell(0, 10, "Energy Waste Incidents (Daily Trend)", ln=True)
pdf.image("waste_chart.png", w=180)

pdf.ln(5)
pdf.set_font("Helvetica", "I", 9)
pdf.multi_cell(0, 6, "Note: This report is based on AI camera detection (person + AC display sensing). Cost estimates use each AC's rated power and the local unit rate - adjust in script as needed for accurate figures.")

output_path = "HFM_Energy_Report.pdf"
pdf.output(output_path)
print(f"Report ban gayi: {output_path}")
