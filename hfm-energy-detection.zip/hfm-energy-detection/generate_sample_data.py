import sqlite3
from datetime import datetime, timedelta
import random

DB_NAME = "hfm_energy.db"
ROOM_NAME = "Demo Room"

conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

cursor.execute("""
    CREATE TABLE IF NOT EXISTS logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT,
        room_name TEXT,
        room_status TEXT,
        ac1_status TEXT,
        ac2_status TEXT,
        phone_count INTEGER,
        alert_sent INTEGER
    )
""")

cursor.execute("DELETE FROM logs")
conn.commit()

print("Purana data clear ho gaya. Ab 7 din ka sample data generate ho raha hai...")

start_time = datetime.now() - timedelta(days=7)
current_time = start_time
INTERVAL_MINUTES = 10
rows_inserted = 0

while current_time < datetime.now():
    hour = current_time.hour
    is_business_hours = 9 <= hour < 18
    is_weekday = current_time.weekday() < 5

    if is_weekday and is_business_hours:
        room_status = "OCCUPIED" if random.random() < 0.75 else "EMPTY"
        ac1_status = "ON"
        ac2_status = "ON"
        phone_count = random.choice([0, 0, 0, 1, 1, 2]) if room_status == "OCCUPIED" else 0
        alert_sent = 1 if (room_status == "EMPTY" and random.random() < 0.3) else 0
    else:
        room_status = "EMPTY"
        ac1_status = "ON" if random.random() < 0.08 else "OFF"
        ac2_status = "ON" if random.random() < 0.08 else "OFF"
        phone_count = 0
        alert_sent = 1 if (ac1_status == "ON" or ac2_status == "ON") else 0

    cursor.execute("""
        INSERT INTO logs (timestamp, room_name, room_status, ac1_status, ac2_status, phone_count, alert_sent)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (current_time.isoformat(), ROOM_NAME, room_status, ac1_status, ac2_status, phone_count, alert_sent))

    rows_inserted += 1
    current_time += timedelta(minutes=INTERVAL_MINUTES)

conn.commit()
conn.close()

print(f"Done! {rows_inserted} sample rows insert ho gayi hain database mein.")
print("Yeh SAMPLE/DEMO data hai, asal detection data nahi.")
