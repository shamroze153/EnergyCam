# HFM Energy Saving Detection

AI camera system that detects when a room is empty but the AC is still running, and sends an email alert (with a snapshot). Built with a pretrained YOLOv8 model for person/phone detection, plus simple ROI-based brightness checks to read each AC's own display/LED status directly from the camera feed - no manual sensors required.

## What it does

- Detects room occupancy (person present or not)
- Detects AC1 / AC2 status independently from each unit's own display
- Detects phone usage (aggregate count, not tied to any individual)
- If the room is empty and an AC is on for longer than a threshold, sends an email alert with a snapshot
- Sends a follow-up "resolved" email once the AC is switched off or someone returns
- Logs everything to a local SQLite database
- Live Streamlit dashboard with occupancy %, wasted hours, and estimated cost
- PDF report generator
- Heartbeat + watchdog script so you get notified if the system itself goes down
- Auto-restart batch script for 24/7 operation

## Setup

1. Create a conda environment and install dependencies:
   ```
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and fill in your actual email and camera credentials.
3. Calibrate the ROI coordinates in `unified_system.py` (`AC1_LX1...`, `AC2_LX1...`) for your specific camera angle - these are specific to one physical camera setup and will need recalibrating per room/camera.
4. Run:
   ```
   python unified_system.py
   ```
5. In a separate terminal, run the dashboard:
   ```
   streamlit run dashboard.py
   ```

## Files

- `unified_system.py` - main detection loop (person + AC + phone + alerts + logging)
- `dashboard.py` - Streamlit live dashboard
- `generate_report.py` - PDF report generator
- `generate_sample_data.py` - fills the database with realistic sample data for demos
- `watchdog.py` - monitors the heartbeat table and alerts if the main system goes silent
- `run_system.bat` - Windows batch script for auto-restart on crash
- `.env.example` - template for required environment variables (copy to `.env` and fill in)

## Notes

This is a working prototype, not a finished product. ROI coordinates for AC/light detection are camera-specific and need manual (or semi-automated) calibration per room. See the project's internal notes for the full roadmap (flap detection, multi-room scaling, fall detection, etc).
